#pragma once
enum class Bonbon
{
    AUCUN = -1,
    BLUE = 0,
    GREEN,
    ORANGE,
    PURPLE,
    RED,
    YELLOW
};